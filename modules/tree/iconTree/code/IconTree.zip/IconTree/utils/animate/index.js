// export this package's api
module.exports = require('./Animate');
